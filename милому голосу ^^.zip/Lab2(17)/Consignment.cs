﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_17_
{
    class Consignment : Vegetable
    {
        Delivery.delivery delivery;//Тип доставки, перечесление
        int count;//Количество поставляемого
        int unitPrice;//Цена за один
        int transportationCost;//Стоимость транспортировки
        DateTime dateDelivery;//дата поставки
        public Consignment(string name, string country, int season, int delivery, int count, int unitPrice, int transportationCost, DateTime dateDelivery) : base(name, country, season)//конструктор с параметрами
        {
            this.delivery = (Delivery.delivery) delivery;
            this.count = count;
            this.unitPrice = unitPrice;
            this.transportationCost = transportationCost;
            this.dateDelivery = dateDelivery;
        }
        public Consignment()//конструктор без параметров
        {
          
        }
        public Delivery.delivery Delivery//свойство для перечесления enum
        {
            get
            {
                return delivery;
            }
            set
            {
                delivery = value;
            }
        }
        public int Count//свойство для переменной количество овощей в партии
        {
            get
            {
                return count;
            }
            set
            {
                count = value;
            }
        }
        public int UnitPrice//свойство для цены за один овощ
        {
            get
            {
                return unitPrice;
            }
            set
            {
                unitPrice = value;
            }
        }
        public int Transportation//свойство для цены перевозки
        {
            get
            {
                return transportationCost;
            }
            set
            {
                transportationCost = value;
            }
        }
        public DateTime DateDelivery//свойство для даты доставки 
        {
            get
            {
                return dateDelivery;
            }
            set
            {
                dateDelivery = value;
            }
        }
        public override string Info()//функция вывода информации про партию и овощ в этой партии
        {
            string info = base.Info();
            info += "Тип доставки «" + delivery + "», количество в партии = " + count + " штук, цена за один: " + unitPrice +
                ", цена транспортировки = " + transportationCost + "\nДата доставки: " + dateDelivery.ToString();
            return info;
        }
    }
}
