﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_17_
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private int season;
        private string name;
        private string country;
        public int Season
        {
            get
            {
               return season;
            }
        }
        public string Name
        {
            get
            {
                return name;
            }
        }
        public string Country
        {
            get
            {
                return country;
            }
        }
        private void OK_MouseEnter(object sender, EventArgs e)
        {
            if (seasonListBox.SelectedIndex == -1 || nameTextBox.Text == "" || countryTextBox.Text == "")
            {
                OK.Enabled = false;
            }
        }
        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {
            if (seasonListBox.SelectedIndex != -1 && nameTextBox.Text != "" && countryTextBox.Text != "")
            {
                OK.Enabled = true;
            }
        }
        private void countryTextBox_TextChanged(object sender, EventArgs e)
        {
            if (seasonListBox.SelectedIndex != -1 && nameTextBox.Text != "" && countryTextBox.Text != "")
            {
                OK.Enabled = true;
            }
        }
        private void seasonListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (seasonListBox.SelectedIndex != -1 && nameTextBox.Text != "" && countryTextBox.Text != "")
            {
                OK.Enabled = true;
            }
        }
        private void OK_Click(object sender, EventArgs e)
        {
            season = seasonListBox.SelectedIndex + 1;
            name = nameTextBox.Text;
            country = countryTextBox.Text;
        }
    }
}
