﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_17_
{
    class Vegetable
    {
        string name;//название овоща
        string country;//страна происхождения
        int season;//сезон созревания
        public Vegetable(string name, string country, int season)//конструктор с параметрами
        {
            this.name = name;
            this.country = country;
            this.season = season;
        }
        public Vegetable()//конструктор без параметров
        {
           
        }
        public string Name//свойство для переменной названия
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public string Country//свойство для переменной страны происхождения
        {
            get
            {
                return country;
            }
            set
            {
                country = value;
            }
        }
        public int Season//свойство для переменной сезона созревания
        {
            get
            {
                return season;
            }
            set
            {
                season = value;
            }
        }
        public virtual string Info()//метод для вывода информации
        {
            string info = "Овощ: " + name + ", страна происхождения " + country + ", сезон созревания: ";
            switch (season)//перевод из числа в строку
            {
                case 1: info += "зима\n"; break;
                case 2: info += "весна\n"; break;
                case 3: info += "лето\n"; break;
                default: info += "осень\n"; break;
            }
            return info;
        }
    }
}
