﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_17_
{
    class Storage
    {
        int number;//номер склада
        int cost;//стоимость обслуживания помещения
        List<Consignment> consignments = new List<Consignment>();//Список уже принятых партий товара
        public Storage()//конструктор без параметров
        {
            
        }
        public Storage(int number, int cost, List<Consignment> consignments)//конструктор с параметрами
        {
            this.number = number;
            this.cost = cost;
            this.consignments = consignments;
        }
        public Storage(int number, int cost)//конструктор с параметрами
        {
            this.number = number;
            this.cost = cost;
        }
        public int Number//свойство для переменной номер склада
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }
        public int Cost//свойство для переменной стоимость обслуживания помещения
        {
            get
            {
                return cost;
            }
            set
            {
                cost = value;
            }
        }
        public List<Consignment> Consignments//свойство для списка из партий товара
        {
            get
            {
                return consignments;
            }
            set
            {
                consignments = value;
            }
        }
        public string Info()//метод для вывода всей информации про склад
        {
            string info = "Номер склада " + number + ", стоимость обслуживания: " + cost + ". На складе хранятся такие партии товаров:";
            for (int i = 0; i < consignments.Count; i++)
            {
                info += "\n" + (i + 1) + ")";
                info += consignments[i].Info();//перебор всех партий товара на складе и добавление про них информации через метод класса consignments
            }
            return info;
        }
        public void AddOne(Consignment consignment)//Метод для добавления ещё одной партии товара в список
        {
                consignments.Add(consignment);
        }
        public void delete(int index)//Метод для удаление какой-то партии товара
        {
            consignments.RemoveAt(index);
        }
        public string ShortInfo()//метод для вывода сокращённой информации с подсчётом стоимости товара со всех партий
        {
            string info = "Номер склада " + number;
            int totalCostOfProducts = 0;
            for (int i = 0; i < consignments.Count; i++)
            {
                totalCostOfProducts += consignments[i].Count * consignments[i].UnitPrice;
            }
            info += ". Общая стоимость всех товаров на складе " + totalCostOfProducts;
            return info;
        }
    }
}
