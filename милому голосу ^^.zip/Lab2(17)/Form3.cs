﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_17_
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            OK.Enabled = false;
        }
        int number;
        int cost;
        public int Number
        {
            get
            {
                return number;
            }
        }
        public int Cost
        {
            get
            {
                return cost;
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (numberTextBox.Text != "")
                OK.Enabled = true;
        }

        private void OK_Click(object sender, EventArgs e)
        {
            number = Convert.ToInt32(numberTextBox.Text);
            cost = (int)numericUpDown1.Value;
        }

        private void numberTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number) && number != 8)//не вводить если не цифра и не клавиша backspace 
            {
                e.Handled = true;
            }
        }
    }
}
