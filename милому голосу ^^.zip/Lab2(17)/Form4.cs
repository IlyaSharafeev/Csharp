﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_17_
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            OK.Enabled = false;
        }
        int delivery;
        int count;
        int unitPrice;
        int transportationCost;
        DateTime dateDelivery;
        public int Delivery
        {
            get
            {
                return delivery;
            }
        }
        public int Count
        {
            get
            {
                return count;
            }
        }
        public int UnitPrice
        {
            get
            {
                return unitPrice;
            }
        }
        public int Transportation
        {
            get
            {
                return transportationCost;
            }
        }
        public DateTime DateDelivery
        {
            get
            {
                return dateDelivery;
            }
        }

        private void monthsListBox_SelectedIndexChanged(object sender, EventArgs e)//Определение дней в месяце для numericUpDown
        {
            int index = monthsListBox.SelectedIndex;
            int year;
            try
            {
                if (index == 0 || index == 2 || index == 4 || index == 6 || index == 7 || index == 9 || index == 11)
                {
                    dateNumericUpDown.Maximum = 31;
                }
                else if (index == 3 || index == 5 || index == 8 || index == 10)
                {
                    dateNumericUpDown.Maximum = 30;
                }
                else if ((year = int.Parse(yearTextBox.Text)) % 4 == 0)
                    dateNumericUpDown.Maximum = 29;
                else
                    dateNumericUpDown.Maximum = 28;
            }
            catch (System.FormatException)
            {
                MessageBox.Show("Для определения количества дней в феврале нужно выбрать год!", "Сообщение");
                dateNumericUpDown.Maximum = 28;
            }
            if (deliveryListBox.SelectedIndex != -1 || yearTextBox.Text != "")
            {
                OK.Enabled = true;
            }
        }
        private void OK_Click(object sender, EventArgs e)
        {
            delivery = deliveryListBox.SelectedIndex;
            count = (int)countNumericUpDown.Value;
            unitPrice = (int)costNumericUpDown.Value;
            transportationCost = (int)transportationNumericUpDown.Value;
            dateDelivery = new DateTime(Convert.ToInt32(yearTextBox.Text), monthsListBox.SelectedIndex + 1, (int)dateNumericUpDown.Value);
        }
        private void deliveryListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (monthsListBox.SelectedIndex != -1 || yearTextBox.Text != "")
            {
                OK.Enabled = true;
            }
        }
        private void yearTextBox_TextChanged(object sender, EventArgs e)
        {
            if (deliveryListBox.SelectedIndex != -1 || monthsListBox.SelectedIndex != -1 || yearTextBox.Text != "")
            {
                OK.Enabled = true;
            }
        }
    }
}
