﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_17_
{
    public class Delivery
    {
        public enum delivery//перечисление типов доставки
        {
            mediator, supplier, ownFunds
        }
    }
}
