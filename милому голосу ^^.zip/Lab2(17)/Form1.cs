﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_17_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Vegetable> vegetables = new List<Vegetable>();
        List<Storage> storages = new List<Storage>();
        private void vegetableButton_Click(object sender, EventArgs e)
        {
            Form2 df = new Form2();
            df.ShowDialog(this);
            if(df.DialogResult == DialogResult.OK)
            {
                Vegetable vegetable = new Vegetable(df.Name, df.Country, df.Season);
                vegetables.Add(vegetable);
                vegetableListBox.Items.Add(df.Name);
            }
        }

        private void storageCreateButton_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.ShowDialog(this);
            if (f3.DialogResult == DialogResult.OK)
            {
                Storage storage = new Storage(f3.Number, f3.Cost);
                storages.Add(storage);
                storageTreeView.Nodes.Add("Склад " + storage.Number);
            }
        }
        private void consignmentButton_Click(object sender, EventArgs e)
        {
            if (vegetableListBox.SelectedIndex != -1 && storageTreeView.SelectedNode != null && storageTreeView.SelectedNode.Level == 0) {
                Form4 f4 = new Form4();
                f4.ShowDialog(this);
                if (f4.DialogResult == DialogResult.OK)
                {
                    int index = vegetableListBox.SelectedIndex;
                    Consignment consignment = new Consignment(vegetables[index].Name, vegetables[index].Country, vegetables[index].Season, f4.Delivery, f4.Count, f4.UnitPrice, f4.Transportation, f4.DateDelivery);
                    storageTreeView.SelectedNode.Nodes.Add("Партия овоща " + vegetables[index].Name + " " + consignment.Count + " штук");
                    storages[storageTreeView.SelectedNode.Index].AddOne(consignment);
                }
            }
            else
                MessageBox.Show("Необходимо выбрать овощ и склад в соответственных списках!", "Сообщение");
        }
        private void shortInfoButton_Click(object sender, EventArgs e)
        {
            if(storageTreeView.SelectedNode != null && storageTreeView.SelectedNode.Level == 0)
            {
                string info = storages[storageTreeView.SelectedNode.Index].ShortInfo();
                MessageBox.Show(info, "Сообщение");
            }
            else
                MessageBox.Show("Необходимо выделить склад!", "Сообщение");
        }

        private void fullInfoButton_Click(object sender, EventArgs e)
        {
            if (storageTreeView.SelectedNode != null)
            {
                string info;
                if (storageTreeView.SelectedNode.Level == 0)
                {
                    info = storages[storageTreeView.SelectedNode.Index].Info();
                    MessageBox.Show(info, "Сообщение");
                }
                else
                {
                    info = storages[storageTreeView.SelectedNode.Parent.Index].Consignments[storageTreeView.SelectedNode.Index].Info();
                    MessageBox.Show(info, "Сообщение");
                }
            }
            else
                MessageBox.Show("Необходимо выделить склад или партию!", "Сообщение");
        }
    }
}
