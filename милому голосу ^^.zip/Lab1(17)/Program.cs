﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_17_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1.Создание склада через конструктор без параметров");
            Storage storage1 = new Storage();

            Console.WriteLine("2.Создание через конструктор с параметрами");
            List<Consignment> consignments = new List<Consignment>();
            Console.WriteLine("Количество партий в складе: ");
            int countConsignments = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < countConsignments; i++)
            {
                Console.WriteLine("Партия " + (i + 1) + "\nВведите название овоща ");
                string name = Console.ReadLine();
                Console.WriteLine("Введите страну происхождения овоща: ");
                string country = Console.ReadLine();
                Console.WriteLine("Введите сезон созревания(1 - зима, 2 - весна, 3 - лето, 4 - осень: ");
                int season = Convert.ToInt32(Console.ReadLine());
                Vegetable vegetable = new Vegetable(name, country, season);
                Console.WriteLine("Тип доставки: 0 - «посредник», 1 - «поставщик», 2 - «собственными средствами»");
                int type = Convert.ToInt32(Console.ReadLine());
                Delivery.delivery delivery = (Delivery.delivery)type;//перевод из int в enum
                Console.WriteLine("Введите количество поставляемых овощей: ");
                int count = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите цену за единицу овоща: ");
                int unitPrice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите стоимость транспортировки: ");
                int transportationCost = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Дата поставки:\nВ каком году?");
                int year = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Месяц поставки(1 - январь ... 12 - декабрь):");
                int month = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Укажите день:");
                int day = Convert.ToInt32(Console.ReadLine());
                DateTime dateDelivery = new DateTime(year, month, day);
                consignments.Add(new Consignment(vegetable, delivery, count, unitPrice, transportationCost, dateDelivery));
            }
            Console.WriteLine("Номер склада(число): ");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Стоимость обслуживания помещения: ");
            int cost = Convert.ToInt32(Console.ReadLine());
            Storage storage2 = new Storage(number, cost, consignments);//создание объекта склад через конструктор с параметрами

            Console.WriteLine("\nВывод полной информации про склад 1:");//вывод информации через два метода двух объектов склад
            string info = storage1.Info();
            Console.WriteLine(info);
            Console.WriteLine("\nВывод сокращённой информации про склад 1:");
            info = storage1.ShortInfo();
            Console.WriteLine(info);
            Console.WriteLine("\nВывод полной информации про склад 2:");
            info = storage2.Info();
            Console.WriteLine(info);
            Console.WriteLine("\nВывод сокращённой информации про склад 2:");
            info = storage2.ShortInfo();
            Console.WriteLine(info);

            int choose;
            Console.WriteLine("В каком складе удалить или добавить партию?");
            switch (choose = Convert.ToInt32(Console.ReadLine()))//выбор объекта и удаление\добавление 1 партии товара
            {
                case 1:
                    storage1.AddDelete();
                    Console.WriteLine("Обновлённая информация: ");
                    info = storage1.Info();
                    Console.WriteLine("\n" + info);
                    info = storage1.ShortInfo();
                    Console.WriteLine("Сокращённая информация: " + info); break;
                default:
                    storage2.AddDelete();
                    Console.WriteLine("Обновлённая информаци: ");
                    info = storage2.Info();
                    Console.WriteLine("\n" + info);
                    info = storage2.ShortInfo();
                    Console.WriteLine("Сокращённая информация: " + info); break;
            }
            Console.ReadKey();
        }
    }
}
