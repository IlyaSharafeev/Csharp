﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_17_
{
    class Consignment//Класс партия товара
    {
        Vegetable vegetable;//Объект класса овощи
        Delivery.delivery delivery;//Тип доставки, перечесление
        int count;//Количество поставляемого
        int unitPrice;//Цена за один
        int transportationCost;//Стоимость транспортировки
        DateTime dateDelivery;//дата поставки
        public Consignment(Vegetable vegetables, Delivery.delivery delivery, int count, int unitPrice, int transportationCost, DateTime dateDelivery)//конструктор с параметрами
        {
            this.vegetable = vegetables;
            this.delivery = delivery;
            this.count = count;
            this.unitPrice = unitPrice;
            this.transportationCost = transportationCost;
            this.dateDelivery = dateDelivery;
        }
        public Consignment()//конструктор без параметров
        {
            this.vegetable = new Vegetable();//создание объекта "Овощ" через его конструктор без параметров
            Console.WriteLine("Тип доставки: 0 - «посредник», 1 - «поставщик», 2 - «собственными средствами»");
            int type = Convert.ToInt32(Console.ReadLine());
            delivery = (Delivery.delivery)type;//перевод из int в enum
            Console.WriteLine("Введите количество поставляемых овощей: ");
            count = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите цену за единицу овоща: ");
            unitPrice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите стоимость транспортировки: ");
            transportationCost = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Дата поставки:\nВ каком году?");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Месяц поставки(1 - январь ... 12 - декабрь):");
            int month = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Укажите день:");
            int day = Convert.ToInt32(Console.ReadLine());
            dateDelivery = new DateTime(year, month, day);//создание переменной DateTime без времени
        }
        public Vegetable Vegetable//свойство для объекта класса овощ
        {
            get
            {
                return vegetable;
            }
            set
            {
                vegetable = value;
            }
        }
        public Delivery.delivery Delivery//свойство для перечесления enum
        {
            get
            {
                return delivery;
            }
            set
            {
                delivery = value;
            }
        }
        public int Count//свойство для переменной количество овощей в партии
        {
            get
            {
                return count;
            }
            set
            {
                count = value;
            }
        }
        public int UnitPrice//свойство для цены за один овощ
        {
            get
            {
                return unitPrice;
            }
            set
            {
                unitPrice = value;
            }
        }
        public int Transportation//свойство для цены перевозки
        {
            get
            {
                return transportationCost;
            }
            set
            {
                transportationCost = value;
            }
        }
        public DateTime DateDelivery//свойство для даты доставки 
        {
            get
            {
                return dateDelivery;
            }
            set
            {
                dateDelivery = value;
            }
        }
        public string Info()//функция вывода информации про партию и овощ в этой партии
        {
            string info = vegetable.Info();
            info += "Тип доставки «" + delivery +"», количество в партии = " + count + " штук, цена за один: " + unitPrice + 
                ", цена транспортировки = " + transportationCost + "\nДата доставки: " + dateDelivery.ToString();
            return info;
        }
    }
}
