﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_17_
{
    class Delivery
    {
        public enum delivery//перечисление типов доставки
        {
            mediator, supplier, ownFunds
        }
    }
}
