﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_17_
{
    class Storage
    {
        int number;//номер склада
        int cost;//стоимость обслуживания помещения
        List<Consignment> consignments = new List<Consignment>();//Список уже принятых партий товара
        public Storage()//конструктор без параметров
        {
            Console.WriteLine("Количество партий в складе: ");
            int count = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < count; i++) //добавление в список объектов типа партия товара для класса склад
            {
                Console.WriteLine("Партия номер " + (i + 1));
                consignments.Add(new Consignment());
            }
            Console.WriteLine("Номер склада(число): ");
            number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Стоимость обслуживания помещения: ");
            cost = Convert.ToInt32(Console.ReadLine());
        }
        public Storage(int number, int cost, List<Consignment> consignments)//конструктор с параметрами
        {
            this.number = number;
            this.cost = cost;
            this.consignments = consignments;
        }
        public int Number//свойство для переменной номер склада
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }
        public int Cost//свойство для переменной стоимость обслуживания помещения
        {
            get
            {
                return cost;
            }
            set
            {
                cost = value;
            }
        }
        public List<Consignment> Consignments//свойство для списка из партий товара
        {
            get
            {
                return consignments;
            }
            set
            {
                consignments = value;
            }
        }
        public string Info()//метод для вывода всей информации про склад
        {
            string info = "Номер склада " + number + ", стоимость обслуживания: " + cost + ". На складе хранятся такие партии товаров:";
            for (int i = 0; i < consignments.Count; i++)
            {
                info += "\n";
                info += consignments[i].Info();//перебор всех партий товара на складе и добавление про них информации через метод класса consignments
            }
            return info;
        }
        public void AddDelete()//Метод для удаление какой-то партии товара или же добавления ещё одной
        {
            Console.WriteLine("Списать со склада партию -> 1, принять партию -> другое число");
            int choose = Convert.ToInt32(Console.ReadLine());
            if (choose == 1)
            {
                Console.WriteLine("Индекс списываемой партии:");
                int index = Convert.ToInt32(Console.ReadLine());
                consignments.RemoveAt(index);
            }
            else
                consignments.Add(new Consignment());
        }
        public string ShortInfo()//метод для вывода сокращённой информации с подсчётом стоимости товара со всех партий
        {
            string info = "Номер склада " + number;
            int totalCostOfProducts = 0;
            for (int i = 0; i < consignments.Count; i++)
            {
                totalCostOfProducts += consignments[i].Count * consignments[i].UnitPrice;
            }
            info += ". Общая стоимость всех товаров на складе " + totalCostOfProducts;
            return info;
        }
    }
}
